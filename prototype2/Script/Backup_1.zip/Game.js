var WIDTH = window.innerWidth;
var HEIGHT = window.innerHeight;
var vCENTER = new THREE.Vector3(0, 0, 0);
var GRIDWH = 100;
	
/*****************************/
//CAMERA//
/*****************************/
var VIEW_ANGLE = 70,
	ASPECT = WIDTH / HEIGHT,
	NEAR = 0.1,
	FAR = 50001;

var SCREEN_WIDTH = window.innerWidth;
var SCREEN_HEIGHT = window.innerHeight;

var Color = {
	White: 0xffffff,
	Black: 0x000000,
	Grey: 0x999999,
	LightGrey: 0x111111,
	Red: 0xff0000,
	Blue: 0x00ff00,
	Green: 0x0000ff,
	COLOR1: 0x77bbff,
	COLOR2: 0x8ec5e5,
	COLOR3: 0x97a8ba,
	Sun: 0xCCC100,
};

var board_to_world = function(position)
{
	// Convert board position into world position
	return {x: 100 * position.x - vGRID_DIM.x / 2, y: 100 * position.y  - vGRID_DIM.y / 2, z: 0};
};

var Game = function()
{
	// A Game object is the highest level object representing entire game
};

Game.prototype.init = function()
{
	var that = this;
	
	this.board = new Board();
	this.board.init();
	
	this.gameIsPaused = false;
	
	this.barriers = [];
	this.barriers.push(new Barrier({x: 2, y: 1}));
	//this.barriers.push(new Barrier({x: 1, y: 1}));
	//this.barriers.push(new Barrier({x: 2, y: 2}));
	this.robot = new Robot({x: 0, y: 0});
	
	this.numberOfMoves = 10;
	this.selectedTile = {x: 0, y: 0};
	this.prevSelectedTile = this.selectedTile;
	
	this.camera = new THREE.PerspectiveCamera(VIEW_ANGLE, ASPECT, NEAR, FAR);
	this.camera.position.z = 700;
	this.camera.position.y = -400;

	this.scene = new THREE.Scene();
	// Add all barriers to scene
	_.each(this.barriers,
				function(element, index)
				{
					that.scene.add(element.object);
				}
			);
	_.each(this.robot.geomList,
				function(element, index)
				{
					that.scene.add(element);
				}
			);

	
	//Make the tiles
	this.tiles = [];
	
	for(var _x = 0; _x < iNUM_BOXES; ++_x)
	{
		this.tiles[_x] = [];
		
		for(var _y = 0; _y < iNUM_BOXES; ++_y)
		{
			var _pos = {x: _x, y: _y};
			//console.log(_pos);
			this.tiles[_x][_y] = new Tile(_pos);
		}
	}
	
	for(var i = 0; i < iNUM_BOXES; ++i)
	{
		_.each(this.tiles[i],
					function(element, index)
					{
						that.scene.add(element.object);
					}
				);
	}
	
	// Spotlight
	var spotlight = new THREE.PointLight(0xffffff, 1, 1000);
	spotlight.position.set(0, -100, 300);
	this.scene.add(spotlight);
	
	// Ambient light
	var ambient_light = new THREE.AmbientLight(0x040404);
	this.scene.add(ambient_light);
  
	this.renderer = new THREE.WebGLRenderer({antialias: true});
	this.renderer.setSize(800, 600);
	this.renderer.setClearColor(0xeeeeee, 1.0);
	document.body.appendChild(this.renderer.domElement);
	
	
	// Setup keyboard events
	this.keys = {};
	document.onkeydown = 
		function(e)
		{
			//console.log('keydown ' + e.which);
			if (e.which)
			{
				if (that.keys[e.which] !== 'triggered')
				{
					that.keys[e.which] = true;
				}
			}
			//console.log(that.keys);
		};
	
	document.onkeyup =
		function(e)
		{
			//console.log('keyup ' + e.which);
			if (e.which)
			{
				that.keys[e.which] = false;
			}
			//console.log(that.keys);
		};
};

Game.prototype.render = function(t)
{
	// Bob the camera a bit
	this.camera.position.x = Math.sin(t / 1000.0) * 60;
	this.camera.position.y = -700 + Math.sin(t / 700.0) * 40;
	this.camera.lookAt(this.scene.position);
	
	this.renderer.render(this.scene, this.camera);
};

Game.prototype.legalRobotMove = function(position)
{
	if (position.x < 0 || position.x > 7)
	{
		return false;
	}
	if (position.y < 0 || position.y > 7)
	{
		return false;
	}
	return true;
};

Game.prototype.handleInput = function()
{
	// Left
	if (this.keys[65] === true)
	{
		this.keys[65] = 'triggered';
		
		var newPosition =
		{
			x: this.robot.boardPosition.x - 1,
			y: this.robot.boardPosition.y
		};
			
		if (this.legalRobotMove(newPosition))
		{
			this.robot.moveTo(newPosition);
		}
	}
	// Right
	if (this.keys[68] === true)
	{
		this.keys[68] = 'triggered';
		var newPosition =
		{
			x: this.robot.boardPosition.x + 1,
			y: this.robot.boardPosition.y
		};
		
		if (this.legalRobotMove(newPosition))
		{
			this.robot.moveTo(newPosition);
		}
	}
	// Up
	if (this.keys[87] === true)
	{
		this.keys[87] = 'triggered';
		var newPosition =
		{
			x: this.robot.boardPosition.x,
			y: this.robot.boardPosition.y + 1
		};
		
		if (this.legalRobotMove(newPosition))
		{
			this.robot.moveTo(newPosition);
		}
	}
	// Down
	if (this.keys[83] === true)
	{
		this.keys[83] = 'triggered';
		var newPosition =
		{
			x: this.robot.boardPosition.x,
			y: this.robot.boardPosition.y - 1
		};
		
		if (this.legalRobotMove(newPosition))
		{
			this.robot.moveTo(newPosition);
		}
	}
	//Left arrow
	if (this.keys[37] === true)
	{
		this.keys[37] = 'triggered';
		this.selectedTile =
		{
			x: this.selectedTile.x - 1,
			y: this.selectedTile.y
		};
	}
	//Up arrow
	if (this.keys[38] === true)
	{
		this.keys[38] = 'triggered';
		this.selectedTile =
		{
			x: this.selectedTile.x,
			y: this.selectedTile.y + 1
		};
	}
	//Right arrow
	if (this.keys[39] === true)
	{
		this.keys[39] = 'triggered';
		this.selectedTile =
		{
			x: this.selectedTile.x + 1,
			y: this.selectedTile.y
		};
	}
	//Down arrow
	if (this.keys[40] === true)
	{
		this.keys[40] = 'triggered';
		this.selectedTile =
		{
			x: this.selectedTile.x,
			y: this.selectedTile.y - 1
		};
	}
		
	if(this.selectedTile.x < 0)
		this.selectedTile.x = iNUM_BOXES - 1;
	if(this.selectedTile.x > iNUM_BOXES - 1)
		this.selectedTile.x = 0;
	
	if(this.selectedTile.y < 0)
		this.selectedTile.y = iNUM_BOXES - 1;
	if(this.selectedTile.y > iNUM_BOXES - 1)
		this.selectedTile.y = 0;
};

Game.prototype.updateTiles = function()
{
	var that = this;
	
	that.tiles[that.prevSelectedTile.x][that.prevSelectedTile.y].isSelected = false;
	that.tiles[that.selectedTile.x][that.selectedTile.y].isSelected = true;
	
	//reset colors
	for(var x = 0; x < iNUM_BOXES; ++x)
	{
		for(var y = 0; y < iNUM_BOXES; ++y)
		{
			var tile = that.tiles[x][y];
			tile.object.material.color = {r: .75, g: .75, b:.75};
			tile.update();
		}
	}
	
	//color the column yellow
	for(var i = 0; i < iNUM_BOXES; ++i)
	{
		//var tile = that.tiles[that.selectedTile.x][i];
		//tile.material.color = that.object.material.color = Color.Yellow;
		var tile = that.tiles[that.selectedTile.x][i].object.material;
		tile.color = {r: 1, g: 1, b:0};
	}
	
	//color the row yellow
	for(var i = 0; i < iNUM_BOXES; ++i)
	{
		var tile = that.tiles[i][that.selectedTile.y].object.material;
		tile.color = {r: 1, g: 1, b:0};
	}
	
	var tile = that.tiles[that.selectedTile.x][that.selectedTile.y].object.material;
	tile.color = {r:1, g:.5, b:0};
	
	that.prevSelectedTile = that.selectedTile;
}

Game.prototype.update = function()
{
	var that = this;
	that.robot.update();
	that.updateTiles();
}

Game.prototype.start = function()
{
	var that = this;
	var time0 = new Date().getTime(); // milliseconds since 1970
	var loop = function()
	{
		var time = new Date().getTime();
		
		// Respond to user input
		that.handleInput();
		//update the robot
		that.update();
		// Render visual frame
		that.render(time - time0);
		// Loop
		requestAnimationFrame(loop, that.renderer.domElement);
	};
	loop();  
};

//// 