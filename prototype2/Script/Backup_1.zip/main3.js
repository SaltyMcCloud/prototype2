function Play()
{
	var game = new Game();
	game.init();
	game.start();
}

Play();