var Types = 
{
	Empty: 'empty',
	HoldsPlayer: 'player',
	HoldsBarrier: 'barrier',
	HoldsGrapPole: 'pole',
};

var TileInfo = function()
{
	this.type = Types.Empty;
}