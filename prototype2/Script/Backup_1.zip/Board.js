var vGRID_DIM = new THREE.Vector3(800, 800);

var iNUM_BOXES = 8;

var Board = function()
{
	//class representing the state of the board
}

Board.prototype.init = function()
{
	this.grid = [];
	
	for(var i = 0; i < iNUM_BOXES; ++i)
	{
		this.grid[i] = [];
		
		for(var j = 0; j < iNUM_BOXES; ++j)
		{
			this.grid[i][j] = new TileInfo();
		}
	}
}

Board.prototype.update = function()
{

}