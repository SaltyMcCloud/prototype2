var Barrier = function(position)
{
	//// A Barrier is a game object
	// Default position if unspecified is at square 0, 0
	this.boardPosition = position || {x: 0, y: 0};
	this.targetPosition = this.boardPosition;
	this.type = 'barrier';
	this.geometry = new THREE.CubeGeometry(90, 90, 90);
	// Geometry should always be around origin
	this.material = new THREE.MeshLambertMaterial({color: 0xff0000});
	this.object = new THREE.Mesh(this.geometry, this.material);
	// A mesh is an Object3D, change its position to move
	this.object.position = board_to_world(this.boardPosition);
	this.isMoving = false;
};

Barrier.prototype.update = function()
{
	this.updateBoardPosition();
}

Barrier.prototype.moveTo = function(position)
{
	if(!this.isMoving)
	{
		this.targetPosition = position;
		isMoving = true;
	}
}

Barrier.prototype.updateBoardPosition = function()
{
	var d_x = (this.targetPosition.x - this.boardPosition.x) / this.speedFactor;
	var d_y = (this.targetPosition.y - this.boardPosition.y) / this.speedFactor;
	
	if(Math.abs(d_x) < .001 && Math.abs(d_y) < .001)
	{
		this.boardPosition = this.targetPosition;
		this.isMoving = false;
	}
	else
	{	
		this.boardPosition.x += d_x;
		this.boardPosition.y += d_y;
	}
	this.headObject.position = this.object.position;
	this.headObject.position.z += this.dim;
	this.object.position = board_to_world(this.boardPosition);
}